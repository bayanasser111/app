//
//  RecommendationQuizView.swift
//  Lume
//

import Foundation
import SwiftUI

// MARK: - 1. data Question
struct RecommendationQuestion {
    let id: Int
    let question: String
    let options: [RecommendationOption]
    let weight: Int
}

struct RecommendationOption: Identifiable {
    let id = UUID()
    let text: String
    let value: String
}

let recommendationQuestions: [RecommendationQuestion] = [
    RecommendationQuestion(
        id: 1,
        question: "ما هي المشكلة الأساسية التي ترغب في علاجها؟",
        options: [
            RecommendationOption(text: "حب الشباب والمسام الواسعة", value: "goal_acne_pores"),
            RecommendationOption(text: "التصبغات وتوحيد لون البشرة", value: "goal_pigmentation"),
            RecommendationOption(text: "التجاعيد والخطوط الدقيقة", value: "goal_anti_aging"),
            RecommendationOption(text: "ترطيب عميق وتقوية حاجز البشرة", value: "goal_hydration")
        ],
        weight: 4
    ),
    RecommendationQuestion(
        id: 2,
        question: "هل تعاني بشرتك حالياً من الجفاف الشديد، التقشر، أو التهيج؟",
        options: [
            RecommendationOption(text: "نعم، البشرة متهيجة حالياً", value: "state_irritated"),
            RecommendationOption(text: "لا، البشرة طبيعية ومستقرة", value: "state_stable")
        ],
        weight: 3
    ),
    RecommendationQuestion(
        id: 3,
        question: "متى تفضل استخدام المنتجات ",
        options: [
            RecommendationOption(text: "الصباح فقط (يتطلب واقي شمس)", value: "time_morning"),
            RecommendationOption(text: "المساء فقط (يسمح بالريتينول والأحماض)", value: "time_night"),
            RecommendationOption(text: "صباحاً ومساءً (Both)", value: "time_both")
        ],
        weight: 2
    ),
    RecommendationQuestion(
        id: 4,
        question: "ما هو نوع المنتج الذي تبحث عنه؟",
        options: [
            RecommendationOption(text: "منظف (Cleanser)", value: "product_cleanser"),
            RecommendationOption(text: "سيروم (Serum)", value: "product_serum"),
            RecommendationOption(text: "مرطب (Moisturizer)", value: "product_moisturizer"),
            RecommendationOption(text: "واقي شمس (Sunscreen)", value: "product_sunscreen")
        ],
        weight: 2
    ),
    RecommendationQuestion(
        id: 5,
        question: "هل لديك أي حساسية تجاه مكون معين؟",
        options: [
            RecommendationOption(text: "نعم، لدي حساسية محددة (مكونات عطرية، كحول...)", value: "has_allergy"),
            RecommendationOption(text: "لا، ليس لدي حساسية", value: "no_allergy")
        ],
        weight: 0
    )
]

// MARK: - 2. شاشة الاختبار الرئيسية
struct RecommendationQuizView: View {
    @EnvironmentObject var appState: AppState
    @Binding var isShowingSheet: Bool
    
    @State private var currentQuestionIndex = 0
    @State private var answers: [Int: String] = [:]
    @State private var showResults = false
    @State private var recommended: [Product] = []
    
    @State private var showContentView = false
    
    var progress: Double {
        Double(currentQuestionIndex + 1) / Double(recommendationQuestions.count)
    }
    
    var currentQuestion: RecommendationQuestion {
        recommendationQuestions[currentQuestionIndex]
    }
    
    var hasAnsweredCurrent: Bool {
        answers[currentQuestion.id] != nil
    }
    
    var body: some View {
        NavigationView {
            ZStack {
                LinearGradient(
                    colors: [Color("black"), Color.white],
                    startPoint: .topLeading,
                    endPoint: .bottomTrailing
                )
                .ignoresSafeArea()
                
                if showResults {
                    RecommendationsView(recommended: recommended, onClose: {
                        appState.completeOnboarding()
                        showContentView = true
                    })
                } else {
                    quizContent
                }
            }
            .navigationBarTitleDisplayMode(.inline)
        }
        .environment(\.layoutDirection, .rightToLeft)
        .fullScreenCover(isPresented: $showContentView) {
            ContentView()
                .environmentObject(appState)
                .navigationBarBackButtonHidden(true)
        }
    }
    
    // MARK: - Quiz Content
    var quizContent: some View {
        ScrollView {
            VStack(spacing: 20) {
                // Header and Progress
                VStack(spacing: 12) {
                    HStack {
                        Text("السؤال \(currentQuestionIndex + 1) من \(recommendationQuestions.count)")
                            .font(.caption)
                    }
                    GeometryReader { geometry in
                        ZStack(alignment: .leading) {
                            Rectangle()
                                .fill(Color.gray.opacity(0.2))
                                .frame(height: 8)
                                .cornerRadius(4)
                            
                            Rectangle()
                                .fill(LinearGradient(colors: [Color.lightblue, Color.lightblue], startPoint: .leading, endPoint: .trailing))
                                .frame(width: geometry.size.width * progress, height: 8)
                                .cornerRadius(4)
                        }
                    }
                    .frame(height: 8)
                }
                .padding()
                .cornerRadius(12)
                .overlay(
                    RoundedRectangle(cornerRadius: 10)
                        .stroke(Color.gray.opacity(0.4), lineWidth: 1)
                )
                
                // Question and Options
                VStack(alignment: .leading, spacing: 16) {
                    Text(currentQuestion.question)
                        .font(.headline)
                        .fixedSize(horizontal: false, vertical: true)
                    
                    ForEach(currentQuestion.options) { option in
                        QuizOptionButton(
                            text: option.text,
                            isSelected: answers[currentQuestion.id] == option.value,
                            action: { answers[currentQuestion.id] = option.value }
                        )
                    }
                }
                .padding()
                .background(Color.white)
                .cornerRadius(12)
                .overlay(
                    RoundedRectangle(cornerRadius: 10)
                        .stroke(Color.gray.opacity(0.4), lineWidth: 1)
                )
                
                // Navigation Buttons
                HStack {
                    if currentQuestionIndex > 0 {
                        Button(action: handleBack) {
                            HStack { Text("السابق") }
                                .padding(.horizontal, 24)
                                .padding(.vertical, 12)
                                .background(Color(UIColor.secondarySystemBackground))
                                .cornerRadius(8)
                                .foregroundStyle(Color.black)
                        }
                    }
                    
                    Spacer()
                    
                    Button(action: handleNext) {
                        HStack {
                            Text(currentQuestionIndex == recommendationQuestions.count - 1 ? "عرض التوصيات" : "التالي")
                        }
                        .padding(.horizontal, 24)
                        .padding(.vertical, 12)
                        .background(
                            hasAnsweredCurrent ?
                                LinearGradient(colors: [Color.lightblue, Color.lightblue], startPoint: .leading, endPoint: .trailing) :
                                LinearGradient(colors: [Color.gray.opacity(0.3)], startPoint: .leading, endPoint: .trailing)
                        )
                        .foregroundColor(.black)
                        .cornerRadius(8)
                    }
                    .disabled(!hasAnsweredCurrent)
                }
                .padding()
                .cornerRadius(8)
            }
            .padding()
        }
    }
    
    // MARK: - Actions
    func handleNext() {
        if currentQuestionIndex < recommendationQuestions.count - 1 {
            withAnimation { currentQuestionIndex += 1 }
        } else {
            let model = buildAnswersModel()
            appState.setRecommendationAnswers(model)
            updateSkinTypeBasedOnAnswers(model)
            
            let top = appState.recommendTopProducts(count: 5)
            self.recommended = Array(top.prefix(5))
            withAnimation { showResults = true }
        }
    }
    
    func handleBack() {
        if currentQuestionIndex > 0 {
            withAnimation { currentQuestionIndex -= 1 }
        }
    }
    
    private func buildAnswersModel() -> RecommendationAnswers {
        let goal: RecommendationAnswers.PrimaryGoal? = {
            switch answers[1] {
            case RecommendationAnswers.PrimaryGoal.acnePores.rawValue: return .acnePores
            case RecommendationAnswers.PrimaryGoal.pigmentation.rawValue: return .pigmentation
            case RecommendationAnswers.PrimaryGoal.antiAging.rawValue: return .antiAging
            case RecommendationAnswers.PrimaryGoal.hydration.rawValue: return .hydration
            default: return nil
            }
        }()
        
        let irritated = (answers[2] == "state_irritated")
        
        let usage: RecommendationAnswers.UsageTime? = {
            switch answers[3] {
            case RecommendationAnswers.UsageTime.morning.rawValue: return .morning
            case RecommendationAnswers.UsageTime.night.rawValue: return .night
            case RecommendationAnswers.UsageTime.both.rawValue: return .both
            default: return nil
            }
        }()
        
        let productPref: RecommendationAnswers.ProductTypePref? = {
            switch answers[4] {
            case RecommendationAnswers.ProductTypePref.cleanser.rawValue: return .cleanser
            case RecommendationAnswers.ProductTypePref.serum.rawValue: return .serum
            case RecommendationAnswers.ProductTypePref.moisturizer.rawValue: return .moisturizer
            case RecommendationAnswers.ProductTypePref.sunscreen.rawValue: return .sunscreen
            default: return nil
            }
        }()
        
        let hasAllergy = (answers[5] == "has_allergy")
        
        return RecommendationAnswers(
            rawSkinTypeAnswer: nil,
            primaryGoal: goal,
            isIrritatedNow: irritated,
            usageTime: usage,
            productTypePreference: productPref,
            hasAllergy: hasAllergy,
            avoidIngredients: []
        )
    }
    
    private func updateSkinTypeBasedOnAnswers(_ answers: RecommendationAnswers) {
        if answers.isIrritatedNow || answers.primaryGoal == .hydration {
            appState.skinType = .dry
        } else if answers.primaryGoal == .acnePores {
            appState.skinType = .oily
        } else if answers.primaryGoal == .pigmentation {
            appState.skinType = .combination
        } else if answers.primaryGoal == .antiAging {
            appState.skinType = .normal
        }
        UserDefaults.standard.set(appState.skinType.rawValue, forKey: "skinType")
    }
}

#Preview {
    RecommendationQuizView(isShowingSheet: .constant(true))
        .environmentObject(AppState())
}
