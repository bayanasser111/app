import SwiftUI

struct ResetRoutineView: View {
    @Binding var isPresented: Bool
    var onReset: () -> Void

    var body: some View {
        Group {
            if isPresented {
                ZStack {
                    VStack(spacing: 15) {
                        Text("إعادة تعيين الروتين؟")
                            .font(.headline)
                            .padding(.top, 10)

                        Text("سيتم حذف كل المنتجات المحفوظة مسبقًا")
                            .font(.subheadline)
                            .foregroundColor(.gray)
                            .multilineTextAlignment(.center)
                            .padding(.horizontal, 20)

                        HStack(spacing: 20) {
                            Button(action: {
                                isPresented = false
                            }) {
                                Text("إلغاء")
                                    .frame(minWidth: 100)
                            }
                            .buttonStyle(.bordered)
                            .tint(.gray.opacity(0.4))

                            Button(action: {
                                onReset()
                                isPresented = false
                            }) {
                                Text("إعادة تعيين")
                                    .frame(minWidth: 100)
                                    .foregroundColor(.black)
                            
                            }
                            .buttonStyle(.borderedProminent)
                            .tint(.lightblue)
                        }
                        .padding(.bottom, 10)
                    }
                    .frame(width: 300)
                    .background(Color.white)
                    .cornerRadius(16)
                    .overlay(
                        RoundedRectangle(cornerRadius: 10)
                            .stroke(Color.gray.opacity(0.4), lineWidth: 1)
                    )
                }
                .transition(.identity)
                .animation(nil, value: isPresented)
            }
        }
    }
}

#Preview {
    ResetRoutineView(isPresented: .constant(true)) {
        print("تمت إعادة التعيين")
    }
}


