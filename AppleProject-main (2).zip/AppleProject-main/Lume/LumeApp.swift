//
//  LumeApp.swift
//  Lume Skincare App
//
//  Main app entry point
//

import SwiftUI

@main
struct LumeApp: App {
    @AppStorage("notificationsPermissionRequested") var notificationsPermissionRequested = false
    @StateObject private var appState = AppState()
    
    var body: some Scene {
        WindowGroup {
            RootView()
                .environmentObject(appState)
                .environment(\.layoutDirection, .rightToLeft)
                .environment(\.locale, Locale(identifier: "ar"))
                .onAppear {
                    if !notificationsPermissionRequested {
                        requestNotificationPermission()
                        notificationsPermissionRequested = true
                    }
                }
        }
    }
}
