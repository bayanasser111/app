//
//  skinQuizdata.swift
//  Lume
//
//  Created by Nouf Baabbad on 16/05/1447 AH.
//

import Foundation
import SwiftUI

// MARK: - Skin Quiz View (Unified UI with SkinQuizView)
struct skinQuizdata: View {
    @EnvironmentObject var appState: AppState
    @Environment(\.dismiss) var dismiss
    @State private var showRecommendationQuiz = false
    
    @State private var currentQuestionIndex = 0
    @State private var answers: [Int: String] = [:]
    
    @State private var showResults = false
    @State private var determinedSkinType: SkinType = .normal
    @State private var showFullQuiz = false // used when user clicks "I don't know"
    
    var progress: Double {
        Double(currentQuestionIndex + 1) / Double(quizQuestions.count)
    }
    
    var currentQuestion: QuizQuestion {
        quizQuestions[currentQuestionIndex]
    }
    
    var hasAnsweredCurrent: Bool {
        answers[currentQuestion.id] != nil
    }
    
    var body: some View {
        NavigationView {
            ZStack {
                LinearGradient(
                    colors: [Color("black"), Color.white],
                    startPoint: .topLeading,
                    endPoint: .bottomTrailing
                )
                .ignoresSafeArea()
                
                if showResults {
                    resultsView
                } else if showFullQuiz {
                    quizView
                } else {
                    skinTypeQuestionView
                }
            }
            .navigationBarTitleDisplayMode(.inline)
        }
        .fullScreenCover(isPresented: $showRecommendationQuiz) {
            RecommendationQuizView(isShowingSheet: $showRecommendationQuiz)
                .environmentObject(appState)
        }
        .navigationViewStyle(StackNavigationViewStyle())
    }
    
    // MARK: - Initial Skin Type Question (centered)
    var skinTypeQuestionView: some View {
        VStack {
            Spacer()
            VStack(spacing: 24) {
                Text("ما هو نوع بشرتك؟")
                    .font(.title2)
                    .bold()
                
                VStack(spacing: 12) {
                    skinTypeBox(title: "جافة", type: .dry)
                    skinTypeBox(title: "دهنية", type: .oily)
                    skinTypeBox(title: "مختلطة", type: .combination)
                    skinTypeBox(title: "طبيعية", type: .normal)
                    
                    Button(action: { showFullQuiz = true }) {
                        Text("لا أعرف نوع بشرتي")
                            .font(.headline)
                            .foregroundColor(.black)
                            .frame(maxWidth: .infinity)
                            .padding()
                            .cornerRadius(12)
                            .overlay(
                                RoundedRectangle(cornerRadius: 10)
                                    .stroke(Color.gray.opacity(0.4), lineWidth: 1)
                            )
                    }
                }
                .padding(.horizontal)
            }
            .padding()
            Spacer()
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity)
    }
    
    @ViewBuilder
    private func skinTypeBox(title: String, type: SkinType) -> some View {
        Button(action: {
            selectSkinType(type)
        }) {
            Text(title)
                .font(.headline)
                .foregroundColor(.primary)
                .frame(maxWidth: .infinity)
                .padding()
                .cornerRadius(12)
                .background(Color.white.opacity(0.001))
                .overlay(
                    RoundedRectangle(cornerRadius: 10)
                        .stroke(Color.gray.opacity(0.4), lineWidth: 1)
                )
        }
        .buttonStyle(.plain)
        .contentShape(Rectangle())
    }
    
    // MARK: - Quiz View (centered when content is short)
    var quizView: some View {
        VStack {
            Spacer() // يدفع المحتوى للنصف
            ScrollView {
                VStack(spacing: 20) {
                    // Header
                    VStack(spacing: 12) {
                        HStack {
                            Text("السؤال \(currentQuestionIndex + 1) من \(quizQuestions.count)")
                                .font(.caption)
                        }
                        
                        // Progress bar
                        GeometryReader { geometry in
                            ZStack(alignment: .leading) {
                                Rectangle()
                                    .fill(Color.gray.opacity(0.2))
                                    .frame(height: 8)
                                    .cornerRadius(4)
                                
                                Rectangle()
                                    .fill(hasAnsweredCurrent ? Color.lightblue : Color.gray.opacity(0.3))
                                    .frame(width: geometry.size.width * progress, height: 8)
                                    .cornerRadius(4)
                            }
                        }
                        .frame(height: 8)
                    }
                    .padding()
                    .cornerRadius(12)
                    .overlay(
                        RoundedRectangle(cornerRadius: 10)
                            .stroke(Color.gray.opacity(0.4), lineWidth: 1)
                    )
                    
                    // Question + options
                    VStack(alignment: .leading, spacing: 16) {
                        Text(currentQuestion.question)
                            .font(.headline)
                            .fixedSize(horizontal: false, vertical: true)
                        
                        ForEach(Array(currentQuestion.options.enumerated()), id: \.offset) { _, option in
                            QuizOptionButton(
                                text: option.text,
                                isSelected: answers[currentQuestion.id] == option.value,
                                action: { answers[currentQuestion.id] = option.value }
                            )
                        }
                    }
                    .padding()
                    .background(Color.white)
                    .cornerRadius(12)
                    .overlay(
                        RoundedRectangle(cornerRadius: 10)
                            .stroke(Color.gray.opacity(0.4), lineWidth: 1)
                    )
                    
                    // Navigation
                    HStack {
                        if currentQuestionIndex > 0 {
                            Button(action: handleBack) {
                                Text("السابق")
                                    .padding(.horizontal, 24)
                                    .padding(.vertical, 12)
                                    .background(Color(UIColor.secondarySystemBackground))
                                    .cornerRadius(8)
                                    .foregroundColor(.black)
                            }
                        }
                        Spacer()
                        Button(action: handleNext) {
                            Text(currentQuestionIndex == quizQuestions.count - 1 ? "انهاء" : "التالي")
                                .padding(.horizontal, 24)
                                .padding(.vertical, 12)
                                .background(
                                    hasAnsweredCurrent ? Color.lightblue : Color.gray.opacity(0.3)
                                )
                                .foregroundColor(.black)
                                .cornerRadius(8)
                        }
                        .disabled(!hasAnsweredCurrent)
                    }
                    .padding()
                    .cornerRadius(8)
                }
                .padding()
            }
            Spacer()
        }
    }
    
    // MARK: - Results View (centered when content is short)
    var resultsView: some View {
        VStack {
            Spacer()
            ScrollView {
                VStack(spacing: 24) {
                    Text("بناء على اجوبتك، قمنا بتحديد نوع بشرتك وهو كالتالي")
                        .font(.subheadline)
                        .foregroundColor(.secondary)
                        .multilineTextAlignment(.center)
                    
                    HStack(spacing: 16) {
                        ZStack {
                            Circle()
                                .fill(Color.white)
                                .frame(width: 64, height: 64)
                                .shadow(radius: 4)
                            Image(systemName: determinedSkinType.iconName)
                                .font(.system(size: 28))
                                .foregroundColor(determinedSkinType.color)
                        }
                        
                        VStack(alignment: .leading, spacing: 4) {
                            Text("نوع بشرتك هو")
                                .font(.caption)
                                .foregroundColor(.secondary)
                            Text(determinedSkinType.title)
                                .font(.title3)
                                .fontWeight(.semibold)
                                .foregroundColor(determinedSkinType.color)
                        }
                        Spacer()
                    }
                    .padding()
                    .background(Color(.systemBackground))
                    .cornerRadius(12)
                    .overlay(
                        RoundedRectangle(cornerRadius: 10)
                            .stroke(Color.gray.opacity(0.4), lineWidth: 1)
                    )
                    
                    Button(action: { handleComplete() }) {
                        Text("اكمل الأسئلة للحصول على توصية")
                            .frame(maxWidth: .infinity)
                            .padding()
                            .background(Color.lightblue)
                            .foregroundColor(.black)
                            .cornerRadius(12)
                    }
                    
                    Button(action: { handleSaveAndClose() }) {
                        Text("انهاء")
                            .frame(maxWidth: .infinity)
                            .padding()
                            .background(Color(UIColor.secondarySystemBackground))
                            .foregroundColor(.black)
                            .cornerRadius(12)
                    }
                    
                    Text("يمكنك دائما اعادة الاختبار من صفحة بشرتي")
                        .font(.caption)
                        .foregroundColor(.secondary)
                        .multilineTextAlignment(.center)
                }
                .padding()
            }
            Spacer()
        }
    }
    
    // MARK: - Actions
    func selectSkinType(_ type: SkinType) {
        appState.skinType = type
        UserDefaults.standard.set(type.rawValue, forKey: "skinType")
        appState.onboardingStep = .recommendationQuiz
        showRecommendationQuiz = true
    }
    
    func handleNext() {
        if currentQuestionIndex < quizQuestions.count - 1 {
            withAnimation { currentQuestionIndex += 1 }
        } else {
            calculateResults()
        }
    }
    
    func handleBack() {
        if currentQuestionIndex > 0 {
            withAnimation { currentQuestionIndex -= 1 }
        }
    }
    
    func calculateResults() {
        var scores = ["dry": 0, "normal": 0, "oily": 0, "combination": 0]
        for question in quizQuestions {
            if let answerValue = answers[question.id] {
                if let option = question.options.first(where: { $0.value == answerValue }) {
                    for (key, value) in option.points { scores[key, default: 0] += value }
                }
            }
        }
        let maxScore = scores.values.max() ?? 0
        if scores["dry"] == maxScore { determinedSkinType = .dry }
        else if scores["oily"] == maxScore { determinedSkinType = .oily }
        else if scores["combination"] == maxScore { determinedSkinType = .combination }
        else { determinedSkinType = .normal }
        withAnimation { showResults = true }
    }
    
    func handleComplete() {
        appState.skinType = determinedSkinType
        UserDefaults.standard.set(determinedSkinType.rawValue, forKey: "skinType")
        appState.onboardingStep = .recommendationQuiz
        showRecommendationQuiz = true
    }
    
    func handleSaveAndClose() {
        appState.skinType = determinedSkinType
        UserDefaults.standard.set(determinedSkinType.rawValue, forKey: "skinType")
        dismiss()
    }
}

#Preview {
    skinQuizdata()
        .environmentObject(AppState())
}

