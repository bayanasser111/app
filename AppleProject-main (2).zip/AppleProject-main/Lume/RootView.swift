import SwiftUI

struct RootView: View {
    @EnvironmentObject var appState: AppState
    
    var body: some View {
        switch appState.onboardingStep {
        case .completed:
            // Main app
            ContentView()
                .environmentObject(appState)
        case .skinQuiz, .recommendationQuiz:
            // Show logo/splash first; LogoPage will route to the right quiz
            logopage()
                .environmentObject(appState)
        }
    }
}

#Preview {
    RootView().environmentObject(AppState())
}
