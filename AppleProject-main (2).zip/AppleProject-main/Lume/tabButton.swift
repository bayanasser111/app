//
//  TapBar.swift
//  Lume
//
//  Created by Nouf Baabbad on 13/05/1447 AH.
//

import SwiftUI

struct BottomTabBar: View {
    @Binding var selectedTab: Int
    
    var body: some View {
        HStack(spacing: 0) {
            
            tabButton(
                icon: "vial.viewfinder",
                title: "المنتجات",
                isSelected: selectedTab == 2
            ) {
                selectedTab = 2
            }
            
            
            tabButton(
                icon: "sparkles",
                title: "بشرتي",
                isSelected: selectedTab == 0
            ) {
                selectedTab = 0
            }
            
            tabButton(
                icon: "calendar.badge.checkmark",
                title: "روتيني",
                isSelected: selectedTab == 1
            ) {
                selectedTab = 1
            }
            
            
        }
        .padding(.vertical, 12)
        .background(Color.white)
        .shadow(color: .black.opacity(0.1), radius: 10, y: -5)
    }
}

// MARK: - Tab Button
struct tabButton: View {
    let icon: String
    let title: String
    let isSelected: Bool
    let action: () -> Void
    
    var body: some View {
        Button(action: action) {
            VStack(spacing: 4) {
                Image(systemName: icon)
                    .font(.system(size: 20))
                
                Text(title)
                    .font(.caption)
            }
            .frame(maxWidth: .infinity)
            .foregroundColor(isSelected ? Color(Color.black.opacity(0.9)) : .gray)
        }
    }
}


