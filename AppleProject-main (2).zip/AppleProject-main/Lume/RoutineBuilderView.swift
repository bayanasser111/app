import SwiftUI
import UserNotifications

// Routine Manager / Editor for a specific routine
struct RoutineManagerView: View {
    @EnvironmentObject var appState: AppState
    @Binding var isShowingSheet: Bool
    
    // The routine we are editing
    let routineId: String
    
    // Local editable state
    @State private var routineName: String = ""
    @State private var reminderOn: Bool = true
    @State private var reminderTime: Date = Date()
    
    @State private var showResetAlert = false
    @State private var isShowingAddProductSheet: Bool = false
    
    // Load current routine from AppState
    private var currentRoutine: Routine? {
        appState.routines.first(where: { $0.id == routineId })
    }
    private var currentProducts: [RoutineStep] {
        (currentRoutine?.products ?? []).sorted { $0.order < $1.order }
    }
    
    // Helpers
    private func loadFromModel() {
        guard let routine = currentRoutine else { return }
        routineName = routine.name
        reminderOn = routine.reminder.enabled
        
        let formatter = DateFormatter()
        formatter.dateFormat = "HH:mm"
        if let date = formatter.date(from: routine.reminder.time) {
            reminderTime = date
        } else {
            // fallback if stored time format differs
            formatter.dateFormat = "h:mm a"
            if let date = formatter.date(from: routine.reminder.time) {
                reminderTime = date
            }
        }
    }
    
    private func persistNameAndReminderToModel() {
        guard var routine = currentRoutine else { return }
        routine.name = routineName.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty ? routine.name : routineName
        
        let formatter = DateFormatter()
        formatter.dateFormat = "HH:mm"
        let timeString = formatter.string(from: reminderTime)
        routine.reminder.enabled = reminderOn
        routine.reminder.time = timeString
        
        appState.updateRoutine(routine)
    }
    
    private func timeString(from date: Date?) -> String {
        guard let date else { return "" }
        let df = DateFormatter()
        df.locale = Locale(identifier: "ar")
        df.dateFormat = "h:mm a"
        return df.string(from: date)
    }
    
    var body: some View {
        ZStack {
            VStack(spacing: 0) {
                ScrollView {
                    VStack(alignment: .leading, spacing: 20) {
                        // Close
                        HStack {
                            Spacer()
                            Button(action: { isShowingSheet = false }) {
                                Image(systemName: "xmark").foregroundColor(.gray)
                            }
                        }
                        
                        // Title
                        HStack {
                            Text("تعديل الروتين")
                                .font(.title2).bold()
                            Spacer()
                        }
                        
                        Text("يمكنك تعديل اسم الروتين، وقت التذكير، إضافة أو حذف المنتجات")
                            .font(.subheadline)
                            .foregroundColor(.gray)
                        
                        // Routine name
                        VStack(alignment: .leading, spacing: 8) {
                            Text("اسم الروتين")
                                .font(.headline)
                            TextField("ادخل اسم الروتين", text: $routineName, onCommit: persistNameAndReminderToModel)
                                .padding(10)
                                .background(Color.white)
                                .cornerRadius(10)
                                .overlay(
                                    RoundedRectangle(cornerRadius: 10)
                                        .stroke(Color.gray.opacity(0.3), lineWidth: 1)
                                )
                                .onChange(of: routineName) { _ in
                                    // Live save or you could debounce; keeping immediate for simplicity
                                    persistNameAndReminderToModel()
                                }
                        }
                        
                        // Reminder Box
                        VStack(alignment: .leading, spacing: 12) {
                            HStack {
                                Text("تذكير الروتين")
                                    .font(.headline)
                                Spacer()
                                Toggle("", isOn: $reminderOn)
                                    .labelsHidden()
                                    .onChange(of: reminderOn) { _ in persistNameAndReminderToModel() }
                            }
                            Text("احصل على اشعار لإكمال روتينك")
                                .font(.subheadline)
                                .foregroundColor(.gray)
                            
                            if reminderOn {
                                HStack {
                                    Image(systemName: "clock")
                                        .foregroundColor(.gray)
                                    DatePicker("", selection: $reminderTime, displayedComponents: .hourAndMinute)
                                        .labelsHidden()
                                        .onChange(of: reminderTime) { _ in persistNameAndReminderToModel() }
                                }
                            }
                        }
                        .padding()
                        .overlay(
                            RoundedRectangle(cornerRadius: 12)
                                .stroke(Color.black.opacity(0.3), lineWidth: 0.5)
                        )
                        .cornerRadius(12)
                        
                        // Add / Reset Buttons
                        HStack(spacing: 12) {
                            Button(action: { isShowingAddProductSheet = true }) {
                                HStack(spacing: 6) {
                                    Text("إضافة منتجات")
                                    Image(systemName: "plus")
                                }
                                .padding(.horizontal, 10)
                                .padding(.vertical, 6)
                                .background(Color(.lightblue))
                                .overlay(
                                    RoundedRectangle(cornerRadius: 8)
                                        .stroke(Color.gray.opacity(0.2), lineWidth: 1)
                                )
                            }
                            .foregroundColor(.black)
                            
                            Button(action: { showResetAlert = true }) {
                                Image(systemName: "arrow.clockwise")
                                    .font(.system(size: 20, weight: .medium))
                                    .foregroundColor(.gray)
                            }
                            
                            Spacer()
                        }
                        
                        // Products List
                        VStack(alignment: .leading, spacing: 15) {
                            if currentProducts.isEmpty {
                                Text("لا توجد منتجات في هذا الروتين")
                                    .foregroundColor(.secondary)
                            } else {
                                ForEach(currentProducts) { step in
                                    RoutineItemView(
                                        name: step.productName,
                                        brand: step.category,
                                        type: step.category,
                                        time: timeString(from: step.reminderTime)
                                    ) {
                                        // delete action
                                        appState.deleteProductFromRoutine(routineId: routineId, productId: step.id)
                                    }
                                }
                            }
                        }
                        
                        Spacer(minLength: 40)
                    }
                    .padding()
                }
            }
            .environment(\.layoutDirection, .rightToLeft)
            
            // Reset Alert
            ResetRoutineAlertView(isPresented: $showResetAlert) {
                appState.resetRoutine(routineId: routineId)
            }
        }
        .sheet(isPresented: $isShowingAddProductSheet) {
            AddProductSheet(isShowingSheet: $isShowingAddProductSheet, routineId: routineId)
                .environmentObject(appState)
        }
        .onAppear {
            loadFromModel()
        }
    }
}

// MARK: - Routine Item View
struct RoutineItemView: View {
    var name: String
    var brand: String
    var type: String
    var time: String
    var onDelete: () -> Void
    
    var body: some View {
        HStack {
            RoundedRectangle(cornerRadius: 8)
                .stroke(Color.gray.opacity(0.3), lineWidth: 1)
                .frame(width: 60, height: 60)
                .overlay(Image(systemName: "drop").font(.title2).foregroundColor(.gray))
            
            VStack(alignment: .leading, spacing: 4) {
                Text(name).font(.headline)
                Text(brand).font(.subheadline).foregroundColor(.gray)
                Text(type).font(.subheadline).foregroundColor(.gray)
                if !time.isEmpty {
                    Text(time).font(.subheadline).foregroundColor(.gray)
                }
            }
            Spacer()
            
            Button(action: onDelete) {
                Image(systemName: "xmark").foregroundColor(.gray)
            }
        }
        .padding(8)
        .background(Color.white)
        .cornerRadius(12)
        .shadow(color: Color.black.opacity(0.03), radius: 4, x: 0, y: 2)
    }
}

// MARK: - Reset Alert View (unchanged)
struct resetRoutineAlertView: View {
    @Binding var isPresented: Bool
    var onConfirm: () -> Void
    
    var body: some View {
        if isPresented {
            Color.black.opacity(0.4)
                .edgesIgnoringSafeArea(.all)
                .onTapGesture { isPresented = false }
            
            VStack(spacing: 20) {
                Text("تأكيد إعادة التعيين").font(.headline)
                Text("هل أنت متأكد من رغبتك في إعادة تعيين الروتين؟").font(.subheadline)
                HStack(spacing: 30) {
                    Button("إلغاء") { isPresented = false }
                    Button("تأكيد") {
                        onConfirm()
                        isPresented = false
                    }
                }
            }
            .padding()
            .frame(width: 300, height: 180)
            .background(Color.white)
            .cornerRadius(15)
        }
    }
}

// Keep the original type name used elsewhere
typealias ResetRoutineAlertView = resetRoutineAlertView

#Preview {
    RoutineManagerView(isShowingSheet: .constant(true), routineId: "morning")
        .environmentObject(AppState())
}
