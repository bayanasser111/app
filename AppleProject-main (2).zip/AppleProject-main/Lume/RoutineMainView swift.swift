import Foundation
import SwiftUI

struct RoutineMainView: View {
    
    @EnvironmentObject var appState: AppState
    @State private var isShowingAddProductSheet: Bool = false
    @State private var isShowingAddRoutineSheet = false
    @State private var isShowingEditSheet = false
    
    @State private var selectedRoutineId: String? = nil
    
    @State private var reminderOn = false
    @State private var reminderTime = Date()
    @State private var deadline: Date = Calendar.current.date(byAdding: .month, value: 1, to: Date())!
    
    @State private var showDeleteAlert: Bool = false
    
    //  Reset confirmation overlay state
    @State private var isShowingReset: Bool = false
    
    var currentRoutine: Routine? {
        guard let id = selectedRoutineId else { return appState.routines.first }
        return appState.routines.first(where: { $0.id == id }) ?? appState.routines.first
    }

    var currentProducts: [RoutineStep] {
        return currentRoutine?.products.sorted(by: { $0.order < $1.order }) ?? []
    }
    
    private func loadReminderFromModel() {
        guard let routine = currentRoutine else { return }
        reminderOn = routine.reminder.enabled
        let formatter = DateFormatter()
        formatter.dateFormat = "HH:mm"
        if let date = formatter.date(from: routine.reminder.time) {
            reminderTime = date
        } else {
            formatter.dateFormat = "h:mm a"
            if let date = formatter.date(from: routine.reminder.time) {
                reminderTime = date
            }
        }
        deadline = routine.deadline
    }
    
    private func persistReminderToModel() {
        guard var routine = currentRoutine else { return }
        let formatter = DateFormatter()
        formatter.dateFormat = "HH:mm"
        let timeString = formatter.string(from: reminderTime)
        routine.reminder.enabled = reminderOn
        routine.reminder.time = timeString
        appState.updateRoutine(routine)
    }
    
    private func persistDeadlineToModel() {
        guard var routine = currentRoutine else { return }
        routine.deadline = deadline
        appState.updateRoutine(routine)
    }
    
    private func timeString(from date: Date?) -> String {
        guard let date else { return "" }
        let df = DateFormatter()
        df.locale = Locale(identifier: "ar")
        df.dateFormat = "h:mm a"
        return df.string(from: date)
    }
    
    
    var body: some View {
        ZStack {
            VStack(spacing: 0) {
                
                // MARK: - Header: Add / Delete Routine Buttons
                HStack {
                    // Delete button (only if routine is deletable)
                    if let routine = currentRoutine, routine.isDeletable {
                        Button(role: .destructive) {
                            showDeleteAlert = true
                        } label: {
                            Image(systemName: "trash")
                                .font(.title2)
                                .foregroundColor(.red)
                        }
                        .alert("حذف الروتين؟", isPresented: $showDeleteAlert) {
                            Button("إلغاء", role: .cancel) {}
                            Button("حذف", role: .destructive) {
                                if let r = currentRoutine {
                                    appState.deleteRoutine(r)
                                    selectedRoutineId = appState.routines.first?.id
                                    loadReminderFromModel()
                                }
                            }
                        } message: {
                            Text("سيتم حذف هذا الروتين وجميع خطواته.")
                        }
                    }
                    
                    Spacer()
                    
                    // NEW: Edit routine button (opens builder/editor)
                    if currentRoutine != nil {
                        Button(action: {
                            isShowingEditSheet = true
                        }) {
                            Image(systemName: "pencil")
                                .font(.title2)
                                .foregroundColor(Color("main"))
                        }
                        .padding(.trailing, 8)
                    }
                    
                    // NEW: Reset routine button (shows confirmation overlay)
                    if currentRoutine != nil {
                        Button(action: {
                            isShowingReset = true
                        }) {
                            Image(systemName: "arrow.clockwise")
                                .font(.title2)
                                .foregroundColor(Color("main"))
                        }
                        .padding(.trailing, 8)
                    }
                    
                    Button(action: {
                        isShowingAddRoutineSheet = true
                    }) {
                        ZStack {
                                Circle()
                                    .fill(Color("lightblue")) // لون خلفية الدائرة
                                    .frame(width: 40, height: 40)
                                Image(systemName: "plus")
                                    .foregroundColor(.black) // لون علامة +
                                    .font(.title2)
                            }
                    }
                    .sheet(isPresented: $isShowingAddRoutineSheet) {
                       addCustomRoutine(isShowingSheet: $isShowingAddRoutineSheet)
                           .environmentObject(appState)
                    }
                }
                .padding(.horizontal)
                .padding(.vertical, 10)

                ScrollView {
                    VStack(alignment: .leading, spacing: 20) {
                        
                        // MARK: - 1. Dynamic Routine Chips
                        ScrollView(.horizontal, showsIndicators: false) {
                            HStack(spacing: 12) {
                                ForEach(appState.routines) { routine in
                                    RoutineChipView(routine: routine, isSelected: selectedRoutineId == routine.id) {
                                        selectedRoutineId = routine.id
                                        loadReminderFromModel()
                                    }
                                }
                            }
                            .padding(.horizontal)
                        }
                        
                        // MARK: - 2. Routine Details & Products
                        VStack(alignment: .leading, spacing: 15) {
                            
                            // Routine Title & Description
                            VStack(alignment: .leading, spacing: 6) {
                                Text(currentRoutine?.name ?? "روتين العناية")
                                    .font(.title3).bold()
                                    .foregroundColor(Color("Textcolor"))
                                
                                Text(currentRoutine?.description ?? "المنتجات المضافة لهذا الروتين:")
                                    .font(.subheadline)
                                    .foregroundColor(.gray)
                            }
                            
                            // Product List
                            VStack(alignment: .leading, spacing: 12) {
                                if currentProducts.isEmpty {
                                    Text("لا توجد منتجات مضافة بعد")
                                        .foregroundColor(Color("Textcolor"))
                                        .padding(.vertical, 10)
                                } else {
                                    ForEach(currentProducts) { productStep in
                                        RoutineProductView(
                                            name: productStep.productName,
                                            brand: productStep.category,
                                            type: productStep.category,
                                            time: timeString(from: productStep.reminderTime)
                                        ) {
                                            if let routineId = currentRoutine?.id {
                                                appState.deleteProductFromRoutine(routineId: routineId, productId: productStep.id)
                                            }
                                        }
                                    }
                                }
                            }
                            
                            // Add Product Button
                            if currentRoutine?.id != nil {
                                Button(action: {
                                    isShowingAddProductSheet = true
                                }) {
                                    HStack(spacing: 6) {
                                        Text("إضافة منتجات")
                                        Image(systemName: "plus")
                                    }
                                    .padding(.vertical, 12)
                                    .frame(maxWidth: .infinity)
                                    .background(Color.lightblue)
                                    .overlay(
                                        RoundedRectangle(cornerRadius: 12)
                                            .stroke(Color.black.opacity(0.3), lineWidth: 0.5)
                                    )
                                    .foregroundColor(.black)
                                    .cornerRadius(10)
                                }
                            }
                            
                        }
                        .padding()
                        .background(Color.white)
                        .cornerRadius(12)
                        .overlay(
                            RoundedRectangle(cornerRadius: 12)
                                .stroke(Color.black.opacity(0.1), lineWidth: 0.8)
                        )
                        
                        // MARK: - 3. Reminder Settings Box
                        VStack(alignment: .leading, spacing: 15) {
                            // Reminder Toggle & Time
                            VStack(alignment: .leading, spacing: 8) {
                                HStack {
                                    VStack(alignment: .leading) {
                                        Text("تذكير بالروتين").font(.headline)
                                        Text("احصل على إشعار لإكمال روتينك").font(.caption).foregroundColor(.gray)
                                    }
                                    Spacer()
                                    Toggle("", isOn: $reminderOn)
                                        .labelsHidden()
                                        .onChange(of: reminderOn) { _ in persistReminderToModel() }
                                }
                                
                                if reminderOn {
                                    HStack {
                                        Image(systemName: "clock").foregroundColor(.gray)
                                        DatePicker("", selection: $reminderTime, displayedComponents: .hourAndMinute)
                                            .labelsHidden()
                                            .onChange(of: reminderTime) { _ in persistReminderToModel() }
                                    }
                                    .padding(.vertical, 5)
                                    .padding(.horizontal, 10)
                                    .background(Color("bblluu"))
                                    .cornerRadius(8)
                                }
                            }
                            
                            Divider()
                            
                            // Deadline Date Picker
                            HStack {
                                VStack(alignment: .leading) {
                                    Text("تاريخ الانتهاء").font(.headline)
                                    Text("يمكنك تعديل تاريخ انتهاء هذا الروتين").font(.caption).foregroundColor(.gray)
                                }
                                Spacer()
                                Image(systemName: "calendar").foregroundColor(.gray)
                                DatePicker("", selection: $deadline, displayedComponents: .date)
                                    .labelsHidden()
                                    .onChange(of: deadline) { _ in persistDeadlineToModel() }
                            }
                        }
                        .padding()
                        .background(Color("white"))
                        .cornerRadius(12)
                        .overlay(
                            RoundedRectangle(cornerRadius: 12)
                                .stroke(Color.black.opacity(0.1), lineWidth: 0.8)
                        )
                        
                    }
                    .padding(.horizontal)
                    .padding(.bottom, 20)
                }
            }
            .onAppear {
                if selectedRoutineId == nil {
                    selectedRoutineId = appState.routines.first?.id
                }
                loadReminderFromModel()
            }
            .environment(\.layoutDirection, .rightToLeft)
            // Present AddProductSheet for the currently selected routine
            .sheet(isPresented: $isShowingAddProductSheet) {
                AddProductSheet(
                    isShowingSheet: $isShowingAddProductSheet,
                    routineId: currentRoutine?.id ?? ""
                )
                .environmentObject(appState)
            }
            // Present Edit/Builder for the currently selected routine
            .sheet(isPresented: $isShowingEditSheet) {
                RoutineManagerView(
                    isShowingSheet: $isShowingEditSheet,
                    routineId: currentRoutine?.id ?? ""
                )
                .environmentObject(appState)
            }
            
            // NEW: Reset confirmation overlay using your ResetRoutineView component
            if isShowingReset {
                ResetRoutineView(isPresented: $isShowingReset) {
                    if let routineId = currentRoutine?.id {
                        appState.resetRoutine(routineId: routineId)
                    }
                }
            }
        }
    }
}

// MARK: - RoutineProductView (Refined Card)
struct RoutineProductView: View {
    var name: String
    var brand: String
    var type: String
    var time: String
    var onDelete: () -> Void
    
    var body: some View {
        HStack(alignment: .center, spacing: 12) {
            ZStack {
                RoundedRectangle(cornerRadius: 8)
                    .fill(Color.gray.opacity(0.1))
                    .frame(width: 50, height: 50)
                Image(systemName: "drop")
                    .font(.title2)
                    .foregroundColor(Color("main"))
            }
            
            VStack(alignment: .leading, spacing: 2) {
                Text(name).font(.headline).foregroundColor(Color("Textcolor"))
                Text("\(brand) • \(type)")
                    .font(.caption)
                    .foregroundColor(.gray)
            }
            
            Spacer()
            
            VStack(alignment: .trailing) {
                Text(time)
                    .font(.subheadline)
                    .foregroundColor(Color("black"))
                
                Button(action: onDelete) {
                    Image(systemName: "trash")
                        .font(.body)
                        .foregroundColor(.black)
                }
            }
        }
        .padding(12)
        .background(Color("white"))
        .cornerRadius(10)
        .overlay(
            RoundedRectangle(cornerRadius: 10)
                .stroke(Color.black.opacity(0.1), lineWidth: 0.5)
        )
    }
}

// MARK: - RoutineChipView
struct RoutineChipView: View {
    let routine: Routine
    let isSelected: Bool
    let action: () -> Void
    
    var body: some View {
        Button(action: action) {
            Text(routine.name)
                .foregroundColor(.black) // Always black
                .padding(.vertical, 8)
                .padding(.horizontal, 16)
                .background(isSelected ? Color("lightblue") : Color("bblluu"))
                .cornerRadius(8)
                .overlay(
                    RoundedRectangle(cornerRadius: 12)
                        .stroke(Color.black.opacity(0.1), lineWidth: 0.5)
                )
        }
    }
}

#Preview {
    RoutineMainView()
       .environmentObject(AppState())
}
