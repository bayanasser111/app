//
//  RecommendationsView.swift
//  Lume
// this is the recommendation page

import SwiftUI

struct RecommendationsView: View {
    @Environment(\.dismiss) var dismiss
    @EnvironmentObject var appState: AppState
    
    // Initial list passed when navigating from the quiz
    let recommended: [Product]
    
    // New: closure to allow parent to dismiss its presentation
    let onClose: () -> Void
    
    // Local, refreshable list for live updates after retake
    @State private var liveRecommended: [Product] = []
    @State private var showingRetakeQuiz = false
    
    var body: some View {
        NavigationView {
            VStack(spacing: 0) {
                Text("بناءً على البيانات التي أدخلتها، نوصي لك بالمنتجات التالية")
                    .font(.headline)
                    .multilineTextAlignment(.center)
                    .padding(.horizontal)
                    .padding(.vertical, 16)
                
                // Actions row: Retake and Refresh
//                HStack(spacing: 12) {
//                    Button {
//                        showingRetakeQuiz = true
//                    } label: {
//                        HStack(spacing: 8) {
//                            Image(systemName: "arrow.clockwise").foregroundColor(.black)
////                            Text("إعادة الاختبار").foregroundColor(.black)
//                        }
//                        .font(.subheadline)
//                        .padding(.horizontal, 12)
//                        .padding(.vertical, 8)
//                        .background(Color(UIColor.secondarySystemBackground))
//                        .cornerRadius(10)
//                    }
//                    
//                    
//                    Spacer()
//                }
//                .padding(.horizontal)
//                .padding(.bottom, 8)
                
                ScrollView {
                    VStack(spacing: 15) {
                        let items = liveRecommended.isEmpty ? recommended : liveRecommended
                        
                        if items.isEmpty {
                            Text("لم نجد توصيات حالياً. جرّب تعديل إجاباتك أو أعد المحاولة.")
                                .foregroundColor(.secondary)
                                .padding(.vertical, 40)
                        } else {
                            // Reuse ProductCard from ProductCatalogView.swift
                            ForEach(items) { product in
                                ProductCard(product: product)
                            }
                        }
                    }
                    .padding(.horizontal)
                    .padding(.top, 10)
                    .padding(.bottom, 15)
                    
                    // Finish button: complete onboarding and close
//                    Button(action: {
//                        // Tell RootView to switch to ContentView
////                        appState.onboardingStep = .completed
//                        // Dismiss this fullScreenCover to reveal ContentView
//                        dismiss()
//                    }) {
//                        Text("ابدأ باستخدام Lume")
//                            .font(.headline)
//                            .frame(maxWidth: .infinity)
//                            .padding()
//                            .background(Color.black)
//                            .foregroundColor(.white)
//                            .cornerRadius(12)
//                    }
                    .padding(.horizontal)
                    .padding(.bottom)
                }
            }
            .environment(\.layoutDirection, .rightToLeft)
//            .navigationBarTitle("توصيات المنتجات", displayMode: .inline)
            .toolbar {
                HStack(spacing: 12) {
                    Button {
                        showingRetakeQuiz = true
                    } label: {
                    
                            Image(systemName: "arrow.clockwise")
                            .foregroundColor(.black)

                        }

                    
                    
                    
                    Spacer()
                }
                // Close button now calls the parent-provided onClose closure
                Button(action: { onClose() }) {
                    Image(systemName: "xmark").foregroundColor(.gray)
                }
            } 
        }
        .onAppear {
            // Initialize live list with incoming recommended if empty
            if liveRecommended.isEmpty {
                liveRecommended = recommended
            }
        }
        .fullScreenCover(isPresented: $showingRetakeQuiz, onDismiss: {
            // After the user finishes the quiz and it dismisses,
            // recompute from the latest answers in AppState.
            refreshFromCurrentAnswers()
            // If you want to auto-close after retake, uncomment the next line:
            // onClose()
        }) {
            RecommendationQuizView(isShowingSheet: $showingRetakeQuiz)
                .environmentObject(appState)
        }
    }
    
    private func refreshFromCurrentAnswers(count: Int = 5) {
        let fresh = appState.recommendTopProducts(count: count)
        liveRecommended = fresh
    }
}

struct RecommendationsView_Previews: PreviewProvider {
    static var previews: some View {
        let app = AppState()
        return RecommendationsView(recommended: Array(app.products.prefix(5)), onClose: {})
            .environmentObject(app)
    }
}
