//
//  SkinQuizView.swift
//  Glow Skincare App
//
//  Skin type quiz with personalized results
//

import SwiftUI

// MARK: - Quiz Question
struct QuizQuestion {
    let id: Int
    let question: String
    let options: [QuizOption]
}

struct QuizOption {
    let text: String
    let value: String
    let points: [String: Int]
}

// MARK: - Quiz Data

let quizQuestions: [QuizQuestion] = [
    QuizQuestion(
        id: 1,
        question: "كيف تشعر بشرتك بعد عدة ساعات من الغسل (دون وضع أي منتجات)؟",
        options: [
            QuizOption(
                text: "مشدودة، متقشرة، أو غير مريحة",
                value: "tight",
                points: ["dry": 3, "normal": 0, "oily": 0, "combination": 1]
            ),
            QuizOption(
                text: "مريحة ومتوازنة",
                value: "balanced",
                points: ["dry": 0, "normal": 3, "oily": 0, "combination": 1]
            ),
            QuizOption(
                text: "لامعة ودهنية في جميع الأماكن",
                value: "greasy",
                points: ["dry": 0, "normal": 0, "oily": 3, "combination": 0]
            ),
            QuizOption(
                text: "دهنية في منطقة T-zone، وجافة على الخدين",
                value: "mixed",
                points: ["dry": 0, "normal": 0, "oily": 0, "combination": 3]
            )
        ]
    ),
    QuizQuestion(
        id: 2,
        question: "ما مدى وضوح المسام لديك؟",
        options: [
            QuizOption(
                text: "غير واضحة تقريبًا أو صغيرة جدًا",
                value: "small",
                points: ["dry": 3, "normal": 1, "oily": 0, "combination": 1]
            ),
            QuizOption(
                text: "صغيرة إلى متوسطة، موزعة بالتساوي",
                value: "medium",
                points: ["dry": 0, "normal": 3, "oily": 1, "combination": 1]
            ),
            QuizOption(
                text: "كبيرة وواضحة، خصوصًا على الأنف والخدين",
                value: "large",
                points: ["dry": 0, "normal": 0, "oily": 3, "combination": 1]
            ),
            QuizOption(
                text: "كبيرة في منطقة T-zone، أصغر على الخدين",
                value: "varied",
                points: ["dry": 0, "normal": 0, "oily": 1, "combination": 3]
            )
        ]
    ),
    QuizQuestion(
        id: 3,
        question: "كم مرة تعاني من الحبوب أو حب الشباب؟",
        options: [
            QuizOption(
                text: "نادراً أو أبداً",
                value: "rarely",
                points: ["dry": 2, "normal": 2, "oily": 0, "combination": 1]
            ),
            QuizOption(
                text: "أحيانًا، ربما مرة أو مرتين في الشهر",
                value: "occasionally",
                points: ["dry": 0, "normal": 2, "oily": 1, "combination": 2]
            ),
            QuizOption(
                text: "متكرر، عدة مرات في الأسبوع",
                value: "frequently",
                points: ["dry": 0, "normal": 0, "oily": 3, "combination": 1]
            ),
            QuizOption(
                text: "في الغالب في منطقة T-zone",
                value: "tzone",
                points: ["dry": 0, "normal": 0, "oily": 1, "combination": 3]
            )
        ]
    ),
    QuizQuestion(
        id: 4,
        question: "كيف تتفاعل بشرتك مع المرطب؟",
        options: [
            QuizOption(
                text: "تمتص بسرعة وأشعر أني أحتاج المزيد",
                value: "absorbs",
                points: ["dry": 3, "normal": 1, "oily": 0, "combination": 1]
            ),
            QuizOption(
                text: "مريحة ومرطبة",
                value: "comfortable",
                points: ["dry": 1, "normal": 3, "oily": 0, "combination": 2]
            ),
            QuizOption(
                text: "ثقيلة أو دهنية",
                value: "heavy",
                points: ["dry": 0, "normal": 0, "oily": 3, "combination": 0]
            ),
            QuizOption(
                text: "بعض المناطق تحتاجها، وأخرى دهنية",
                value: "uneven",
                points: ["dry": 0, "normal": 0, "oily": 0, "combination": 3]
            )
        ]
    ),
    QuizQuestion(
        id: 5,
        question: "كيف تبدو بشرتك عند منتصف اليوم؟",
        options: [
            QuizOption(
                text: "باهتة وقد تحتوي على جفاف",
                value: "dull",
                points: ["dry": 3, "normal": 0, "oily": 0, "combination": 1]
            ),
            QuizOption(
                text: "نضرة مثل الصباح",
                value: "fresh",
                points: ["dry": 0, "normal": 3, "oily": 0, "combination": 1]
            ),
            QuizOption(
                text: "لامعة وأحتاج لمسح الزيت",
                value: "shiny",
                points: ["dry": 0, "normal": 0, "oily": 3, "combination": 1]
            ),
            QuizOption(
                text: "لامعة في T-zone والخدين طبيعيان",
                value: "mixed-shine",
                points: ["dry": 0, "normal": 0, "oily": 1, "combination": 3]
            )
        ]
    ),
    QuizQuestion(
        id: 6,
        question: "كيف تشعر بشرتك في الطقس المختلف؟",
        options: [
            QuizOption(
                text: "جافة وغير مريحة في الطقس البارد أو الجاف",
                value: "sensitive-dry",
                points: ["dry": 3, "normal": 1, "oily": 0, "combination": 1]
            ),
            QuizOption(
                text: "متوازنة على مدار السنة",
                value: "consistent",
                points: ["dry": 0, "normal": 3, "oily": 1, "combination": 1]
            ),
            QuizOption(
                text: "تصبح أكثر دهنية في الطقس الحار والرطب",
                value: "humid-oily",
                points: ["dry": 0, "normal": 0, "oily": 3, "combination": 1]
            ),
            QuizOption(
                text: "تتغير حسب الموسم",
                value: "seasonal",
                points: ["dry": 1, "normal": 1, "oily": 1, "combination": 3]
            )
        ]
    )
]

// MARK: - Skin Quiz View
struct SkinQuizView: View {
    @EnvironmentObject var appState: AppState
    @Environment(\.dismiss) var dismiss
    @Binding var isShowingSheet: Bool
    var startFullQuiz: Bool = false
    
    // Initial selection state
    @State private var showingFullQuiz = false
    
    @State private var currentQuestionIndex = 0
    @State private var answers: [Int: String] = [:]
    @State private var showResults = false
    @State private var determinedSkinType: SkinType = .normal
    // NEW: Present recommendation quiz directly after results
    @State private var showRecommendationQuiz = false
    
    var progress: Double {
        Double(currentQuestionIndex + 1) / Double(quizQuestions.count)
    }
    
    var currentQuestion: QuizQuestion {
        quizQuestions[currentQuestionIndex]
    }
    
    var hasAnsweredCurrent: Bool {
        answers[currentQuestion.id] != nil
    }
    
    init(isShowingSheet: Binding<Bool>, startFullQuiz: Bool = false) {
        self._isShowingSheet = isShowingSheet
        self.startFullQuiz = startFullQuiz
        _showingFullQuiz = State(initialValue: startFullQuiz)
    }
    
    var body: some View {
        NavigationView {
            ZStack {
                LinearGradient(
                    colors: [Color("black"), Color.white],
                    startPoint: .topLeading,
                    endPoint: .bottomTrailing
                )
                .ignoresSafeArea()
                
                if !showingFullQuiz && !showResults {
                    // Initial entry screen
                    initialSelectionView
                } else if showResults {
                    resultsView
                } else {
                    quizView
                }
            }
            .navigationBarTitleDisplayMode(.inline)
        }
        // Present the recommendation quiz full-screen when requested
        .fullScreenCover(isPresented: $showRecommendationQuiz) {
            RecommendationQuizView(isShowingSheet: $showRecommendationQuiz)
                .environmentObject(appState)
        }
    }
    
    // MARK: - Initial Selection View
    var initialSelectionView: some View {
        VStack(spacing: 24) {
            Text("ما هو نوع بشرتك؟")
                .font(.title2)
                .bold()

            VStack(spacing: 12) {
                skinTypeBox(title: "جافة", type: .dry)
                skinTypeBox(title: "دهنية", type: .oily)
                skinTypeBox(title: "مختلطة", type: .combination)
                skinTypeBox(title: "طبيعية", type: .normal)

                Button(action: { showingFullQuiz = true }) {
                    Text("لا أعرف نوع بشرتي")
                        .font(.headline)
                        .foregroundColor(.black)
                        .frame(maxWidth: .infinity)
                        .padding()
                        .cornerRadius(12)
                        .overlay(
                            RoundedRectangle(cornerRadius: 10)
                                .stroke(Color.gray.opacity(0.4), lineWidth: 1)
                        )
                }
            }
            .padding(.horizontal)
        }
        .padding()
    }
    @ViewBuilder
    private func skinTypeBox(title: String, type: SkinType) -> some View {
        Button(action: {
            selectKnownSkinType(type)
        }) {
            Text(title)
                .font(.headline)
                .foregroundColor(.primary)
                .frame(maxWidth: .infinity)
                .padding()
                .cornerRadius(12)
                .background(Color.white.opacity(0.001))
                .overlay(
                    RoundedRectangle(cornerRadius: 10)
                        .stroke(Color.gray.opacity(0.4), lineWidth: 1)
                )
        }
        .buttonStyle(.plain)
        .contentShape(Rectangle())
    }

    
    // MARK: - Quiz View
    var quizView: some View {
        ScrollView {
            VStack(spacing: 20) {
                // Header
                VStack(spacing: 12) {
                    HStack {
                        Text("السوال \(currentQuestionIndex + 1) من \(quizQuestions.count)")
                            .font(.caption)

                    }
                    
                    // Progress Bar
                    GeometryReader { geometry in
                        ZStack(alignment: .leading) {
                            Rectangle()
                                .fill(Color.gray.opacity(0.2))
                                .frame(height: 8)
                                .cornerRadius(4)
                            
                            Rectangle()
                                .fill(LinearGradient(colors: [Color.lightblue, Color.lightblue], startPoint: .leading, endPoint: .trailing))
                                .frame(width: geometry.size.width * progress, height: 8)
                                .cornerRadius(4)
                        }
                    }
                    .frame(height: 8)
                }
                .padding()
                .cornerRadius(12)
                .overlay(
                    RoundedRectangle(cornerRadius: 10)
                        .stroke(Color.gray.opacity(0.4), lineWidth: 1)
                )

                
                
                // Question
                VStack(alignment: .leading, spacing: 16) {
                    Text(currentQuestion.question)
                        .font(.headline)
                        .fixedSize(horizontal: false, vertical: true)
                    
                    // Options
                    ForEach(Array(currentQuestion.options.enumerated()), id: \.offset) { _, option in
                        QuizOptionButton(
                            text: option.text,
                            isSelected: answers[currentQuestion.id] == option.value,
                            action: {
                                answers[currentQuestion.id] = option.value
                            }
                        )
                    }
                }
                .padding()
                .background(Color.white)
                .cornerRadius(12)
                .overlay(
                    RoundedRectangle(cornerRadius: 10)
                        .stroke(Color.gray.opacity(0.4), lineWidth: 1)
                )
                
                // Navigation
                HStack {
                    if currentQuestionIndex > 0 {
                        Button(action: handleBack) {
                            HStack {
                                Text("السابق")
                            }
                            .padding(.horizontal, 24)
                            .padding(.vertical, 12)
                            .background(Color(UIColor.secondarySystemBackground))
                            .cornerRadius(8)
                            .foregroundStyle(Color.black)
                        }
                    }
                    
                    Spacer()
                    Button(action: handleNext) {
                        HStack {
                            Text(currentQuestionIndex == quizQuestions.count - 1 ? "انهاء" : "التالي")
                        }
                        .padding(.horizontal, 24)
                        .padding(.vertical, 12)
                        .background(
                            hasAnsweredCurrent ?
                                LinearGradient(colors: [Color.lightblue, Color.lightblue], startPoint: .leading, endPoint: .trailing) :
                                LinearGradient(colors: [Color.gray.opacity(0.3)], startPoint: .leading, endPoint: .trailing)
                        )
                        .foregroundColor(.black)
                        .cornerRadius(8)
                    }
                    .disabled(!hasAnsweredCurrent)
                }
                .padding()
                .cornerRadius(8)
            }
            .padding()
        }
    }
    
    // MARK: - Results View
    var resultsView: some View {
        ScrollView {
            VStack(spacing: 24) {
                VStack(spacing: 12) {
                    Text("بناء على اجوبتك، قمنا بتحديد نوع بشرتك وهو كالتالي")
                        .font(.subheadline)
                        .foregroundColor(.secondary)
                        .multilineTextAlignment(.center)
                }
                .padding()
                
                VStack(spacing: 0) {
                    HStack(spacing: 16) {
                        ZStack {
                            Circle()
                                .fill(Color.white)
                                .frame(width: 64, height: 64)
                                .shadow(radius: 4)
                            
                            Image(systemName: determinedSkinType.iconName)
                                .font(.system(size: 28))
                                .foregroundColor(determinedSkinType.color)
                        }
                        
                        VStack(alignment: .leading, spacing: 4) {
                            Text("نوع بشرتك هو")
                                .font(.caption)
                                .foregroundColor(.secondary)
                            
                            Text(determinedSkinType.title)
                                .font(.title3)
                                .fontWeight(.semibold)
                                .foregroundColor(determinedSkinType.color)
                        }
                        
                        Spacer()
                    }
                    .padding()
                }
                .background(Color(.systemBackground))
                .cornerRadius(12)
                .overlay(
                    RoundedRectangle(cornerRadius: 10)
                        .stroke(Color.gray.opacity(0.4), lineWidth: 1)
                )
                
                // Save and continue to recommendation quiz
                Button(action: {
                    handleComplete() // Persist new skin type then open recommendation quiz
                }) {
                    Text("اكمل الأسئلة للحصول على توصية")
                        .frame(maxWidth: .infinity)
                        .padding()
                        .background(
                            LinearGradient(colors: [Color.lightblue, Color.lightblue.opacity(0.9)], startPoint: .leading, endPoint: .trailing)
                        )
                        .overlay(
                            RoundedRectangle(cornerRadius: 10)
                                .stroke(Color.gray.opacity(0.4), lineWidth: 1)
                        )
                        .foregroundColor(.black)
                        .cornerRadius(12)
                }
                .navigationDestination(isPresented: $showRecommendationQuiz) {
                    RecommendationQuizView(isShowingSheet: .constant(true))
                        .environmentObject(appState)
                }
                // Save and return to Dashboard
                Button(action: {
                    handleSaveAndClose()
                }) {
                    Text("انهاء")
                        .frame(maxWidth: .infinity)
                        .padding()
                        .background(Color(UIColor.secondarySystemBackground))
                        .foregroundColor(.black)
                        .cornerRadius(12)
                }
                
                Text("يمكنك دائما اعادة الاختبار من صفحة بشرتي")
                    .font(.caption)
                    .foregroundColor(.secondary)
                    .multilineTextAlignment(.center)
            }
            .padding()
        }
    }
    
    // MARK: - Actions
    private func selectKnownSkinType(_ type: SkinType) {
        // User knows their skin type; skip quiz and go directly to recommendation questions
        appState.skinType = type
        UserDefaults.standard.set(type.rawValue, forKey: "skinType")
        // Advance onboarding flow and present recommendation quiz
        appState.onboardingStep = .recommendationQuiz
        showRecommendationQuiz = true
    }
    
    func handleNext() {
        if currentQuestionIndex < quizQuestions.count - 1 {
            withAnimation {
                currentQuestionIndex += 1
            }
        } else {
            calculateResults()
        }
    }
    
    func handleBack() {
        if currentQuestionIndex > 0 {
            withAnimation {
                currentQuestionIndex -= 1
            }
        }
    }
    
    func calculateResults() {
        var scores = ["dry": 0, "normal": 0, "oily": 0, "combination": 0]
        
        for question in quizQuestions {
            if let answerValue = answers[question.id] {
                if let option = question.options.first(where: { $0.value == answerValue }) {
                    for (key, value) in option.points {
                        scores[key, default: 0] += value
                    }
                }
            }
        }
        
        let maxScore = scores.values.max() ?? 0
        
        if scores["dry"] == maxScore {
            determinedSkinType = .dry
        } else if scores["oily"] == maxScore {
            determinedSkinType = .oily
        } else if scores["combination"] == maxScore {
            determinedSkinType = .combination
        } else {
            determinedSkinType = .normal
        }
        
        withAnimation {
            showResults = true
        }
    }
    
    // Save + open recommendation quiz
    func handleComplete() {
        appState.skinType = determinedSkinType
        UserDefaults.standard.set(determinedSkinType.rawValue, forKey: "skinType")
        // Advance onboarding flow and present recommendation quiz
        appState.onboardingStep = .recommendationQuiz
        showRecommendationQuiz = true
    }
    
    // Save + dismiss back to Dashboard
    func handleSaveAndClose() {
        appState.skinType = determinedSkinType
        UserDefaults.standard.set(determinedSkinType.rawValue, forKey: "skinType")
        // If presented as a sheet, close it
        isShowingSheet = false
        // If embedded in a NavigationStack, also try dismiss
        dismiss()
    }
}

// MARK: - Quiz Option Button
struct QuizOptionButton: View {
    let text: String
    let isSelected: Bool
    let action: () -> Void
    
    var body: some View {
        Button(action: action) {
            HStack(alignment: .top, spacing: 12) {
                ZStack {
                    Circle()
                        .strokeBorder(Color.gray.opacity(0.3), lineWidth: 2)
                        .background(Circle().fill(Color.clear))
                        .frame(width: 20, height: 20)
                    
                    if isSelected {
                        Circle()
                            .fill(Color.black)
                            .frame(width: 8, height: 8)
                    }
                }
                .padding(.top, 2)
                
                Text(text)
                    .font(.subheadline)
                    .foregroundColor(.primary)
                    .multilineTextAlignment(.leading)
                    .frame(maxWidth: .infinity, alignment: .leading)
                
            }
            .padding()
            .overlay(
                RoundedRectangle(cornerRadius: 10)
                    .stroke(Color.gray.opacity(0.4), lineWidth: 1)
            )
        }
        .buttonStyle(PlainButtonStyle())
    }
}



private extension Button {
    func skinTypeButton() -> some View {
        self
            .frame(maxWidth: .infinity)
            .padding()
            .background(Color.white)
            .overlay(
                RoundedRectangle(cornerRadius: 10)
                    .stroke(Color.gray.opacity(0.4), lineWidth: 1)
            )
       
            .cornerRadius(12)
            .foregroundColor(.black)
    }
    func secondaryButton() -> some View {
        self
            .frame(maxWidth: .infinity)
            .padding()
            .cornerRadius(12)
            .foregroundColor(.black)
            .overlay(
                RoundedRectangle(cornerRadius: 10)
                    .stroke(Color.gray.opacity(0.4), lineWidth: 1)
            )
    }
}

#Preview {
    SkinQuizView(isShowingSheet: .constant(true))
        .environmentObject(AppState())
}
