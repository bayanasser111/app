//
//  LumeReminderLiveActivity.swift
//  LumeReminder
//
//  Created by Nouf Baabbad on 17/05/1447 AH.
//

import ActivityKit
import WidgetKit
import SwiftUI

struct LumeReminderAttributes: ActivityAttributes {
    public struct ContentState: Codable, Hashable {
        // Dynamic stateful properties about your activity go here!
        var emoji: String
    }

    // Fixed non-changing properties about your activity go here!
    var name: String
}

struct LumeReminderLiveActivity: Widget {
    var body: some WidgetConfiguration {
        ActivityConfiguration(for: LumeReminderAttributes.self) { context in
            // Lock screen/banner UI goes here
            VStack {
                Text("Hello \(context.state.emoji)")
            }
            .activityBackgroundTint(Color.cyan)
            .activitySystemActionForegroundColor(Color.black)

        } dynamicIsland: { context in
            DynamicIsland {
                // Expanded UI goes here.  Compose the expanded UI through
                // various regions, like leading/trailing/center/bottom
                DynamicIslandExpandedRegion(.leading) {
                    Text("Leading")
                }
                DynamicIslandExpandedRegion(.trailing) {
                    Text("Trailing")
                }
                DynamicIslandExpandedRegion(.bottom) {
                    Text("Bottom \(context.state.emoji)")
                    // more content
                }
            } compactLeading: {
                Text("L")
            } compactTrailing: {
                Text("T \(context.state.emoji)")
            } minimal: {
                Text(context.state.emoji)
            }
            .widgetURL(URL(string: "http://www.apple.com"))
            .keylineTint(Color.red)
        }
    }
}

extension LumeReminderAttributes {
    fileprivate static var preview: LumeReminderAttributes {
        LumeReminderAttributes(name: "World")
    }
}

extension LumeReminderAttributes.ContentState {
    fileprivate static var smiley: LumeReminderAttributes.ContentState {
        LumeReminderAttributes.ContentState(emoji: "😀")
     }
     
     fileprivate static var starEyes: LumeReminderAttributes.ContentState {
         LumeReminderAttributes.ContentState(emoji: "🤩")
     }
}

#Preview("Notification", as: .content, using: LumeReminderAttributes.preview) {
   LumeReminderLiveActivity()
} contentStates: {
    LumeReminderAttributes.ContentState.smiley
    LumeReminderAttributes.ContentState.starEyes
}
