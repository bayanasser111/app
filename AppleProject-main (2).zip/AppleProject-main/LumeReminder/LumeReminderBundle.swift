//
//  LumeReminderBundle.swift
//  LumeReminder
//
//  Created by Nouf Baabbad on 17/05/1447 AH.
//

import WidgetKit
import SwiftUI

@main
struct LumeReminderBundle: WidgetBundle {
    var body: some Widget {
        LumeReminder()
        LumeReminderControl()
        LumeReminderLiveActivity()
    }
}
